package Java.Itvedant.Daily;
interface om{
    void a(int a);

}
public class LambdaEx2 {

        public static void main(String[] args) {
            om k= (int x)->{
                System.out.println("hi i m inside lambda");
            };
        }


}

